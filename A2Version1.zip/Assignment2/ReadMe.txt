﻿//BIT 265
//Assignment 2
//Joan Dawson
This assignment is to handle a log in process using a code first approach.
The program uses Home and Account controllers. The Account
controller handles most of the login/logout logic, and the create logic. 
The Activity model contains references to the user's activity, which is referenced
in the Index page. The program is still having problems building, because it says
'No connection string named 'VisitorLog' could be found in the application config file.'
